use super::*;

#[gpui::test]
fn unicode_ranges_and_graphemes_keep_exact_source(cx: &mut gpui::TestAppContext) {
    let input = cx.new(|cx| {
        let mut input = TextInput::new(cx);
        input.content = "résumé 東京 👩‍💻".into();
        input
    });
    input.read_with(cx, |input, _| {
        for (index, _) in input.content.char_indices() {
            assert_eq!(input.offset_from_utf16(input.offset_to_utf16(index)), index);
        }
        let emoji = input.content.find('👩').expect("emoji");
        assert_eq!(input.next_boundary(emoji), input.content.len());
        assert_eq!(input.previous_boundary(input.content.len()), emoji);
        assert_eq!(input.range_from_utf16(&(0..1000)), 0..input.content.len());
    });
}

#[gpui::test]
fn preedit_replacement_uses_offsets_in_the_composed_text(cx: &mut gpui::TestAppContext) {
    let input = cx.new(TextInput::new);
    input.update(cx, |input, cx| {
        input.content = "résumé ".into();
        input.selected_range = input.content.len()..input.content.len();
        input.compose(None, "東京", Some(1..2), cx);
        assert_eq!(input.content.as_ref(), "résumé 東京");
        assert_eq!(input.selected_range, "résumé 東".len().."résumé 東京".len());
        input.compose(None, "東京都", Some(3..3), cx);
        assert_eq!(input.content.as_ref(), "résumé 東京都");
        assert_eq!(
            input.selected_range,
            input.content.len()..input.content.len()
        );
        assert_eq!(
            input.marked_range,
            Some("résumé ".len()..input.content.len())
        );
    });
}
