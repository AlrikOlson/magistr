//! Text editing for the native comparison, derived from GPUI's input example.
//! Apache-2.0; Zed Industries, upstream c66312b200d113694fca08c1d468669028a09a0e.
use std::ops::Range;

use gpui::{
    App, Bounds, ClipboardItem, Context, CursorStyle, ElementId, ElementInputHandler, Entity,
    EntityInputHandler, FocusHandle, Focusable, GlobalElementId, KeyBinding, LayoutId,
    MouseButton, MouseDownEvent, MouseMoveEvent, MouseUpEvent, PaintQuad, Pixels, Point,
    ShapedLine, SharedString, Style, TextRun, UTF16Selection, Window,
    actions, div, fill, point, prelude::*, px, relative,
    rgb, rgba, size,
};
use unicode_segmentation::UnicodeSegmentation;

actions!(
    text_input,
    [
        Backspace,
        Delete,
        Left,
        Right,
        SelectLeft,
        SelectRight,
        SelectAll,
        Home,
        End,
        ShowCharacterPalette,
        Paste,
        Cut,
        Copy,
        Quit,
    ]
);

pub(crate) struct TextInput {
    focus_handle: FocusHandle,
    content: SharedString,
    placeholder: SharedString,
    selected_range: Range<usize>,
    selection_reversed: bool,
    marked_range: Option<Range<usize>>,
    last_layout: Option<InputLayout>,
    last_bounds: Option<Bounds<Pixels>>,
    is_selecting: bool,
    light: bool,
}

impl TextInput {
    pub(crate) fn new(cx: &mut Context<Self>) -> Self {
        Self { focus_handle: cx.focus_handle(), content: "".into(),
            placeholder: "Ask about this work…".into(), selected_range: 0..0,
            selection_reversed: false, marked_range: None, last_layout: None,
            last_bounds: None, is_selecting: false, light: false }
    }
    pub(crate) fn set_light(&mut self, light: bool, cx: &mut Context<Self>) { self.light = light; cx.notify(); }
    pub(crate) fn value(&self) -> &str { &self.content }
    pub(crate) fn clear(&mut self, cx: &mut Context<Self>) { self.reset(); cx.notify(); }
    pub(crate) fn bind(cx: &mut App) {
        cx.bind_keys([
            KeyBinding::new("backspace", Backspace, Some("TextInput")),
            KeyBinding::new("delete", Delete, Some("TextInput")),
            KeyBinding::new("left", Left, Some("TextInput")),
            KeyBinding::new("right", Right, Some("TextInput")),
            KeyBinding::new("shift-left", SelectLeft, Some("TextInput")),
            KeyBinding::new("shift-right", SelectRight, Some("TextInput")),
            KeyBinding::new("cmd-a", SelectAll, Some("TextInput")),
            KeyBinding::new("cmd-c", Copy, Some("TextInput")),
            KeyBinding::new("cmd-v", Paste, Some("TextInput")),
            KeyBinding::new("cmd-x", Cut, Some("TextInput")),
            KeyBinding::new("cmd-left", Home, Some("TextInput")),
            KeyBinding::new("cmd-right", End, Some("TextInput")),
        ]);
    }

    fn left(&mut self, _: &Left, _: &mut Window, cx: &mut Context<Self>) {
        if self.selected_range.is_empty() {
            self.move_to(self.previous_boundary(self.cursor_offset()), cx);
        } else {
            self.move_to(self.selected_range.start, cx)
        }
    }

    fn right(&mut self, _: &Right, _: &mut Window, cx: &mut Context<Self>) {
        if self.selected_range.is_empty() {
            self.move_to(self.next_boundary(self.selected_range.end), cx);
        } else {
            self.move_to(self.selected_range.end, cx)
        }
    }

    fn select_left(&mut self, _: &SelectLeft, _: &mut Window, cx: &mut Context<Self>) {
        self.select_to(self.previous_boundary(self.cursor_offset()), cx);
    }

    fn select_right(&mut self, _: &SelectRight, _: &mut Window, cx: &mut Context<Self>) {
        self.select_to(self.next_boundary(self.cursor_offset()), cx);
    }

    fn select_all(&mut self, _: &SelectAll, _: &mut Window, cx: &mut Context<Self>) {
        self.move_to(0, cx);
        self.select_to(self.content.len(), cx)
    }

    fn home(&mut self, _: &Home, _: &mut Window, cx: &mut Context<Self>) {
        self.move_to(0, cx);
    }

    fn end(&mut self, _: &End, _: &mut Window, cx: &mut Context<Self>) {
        self.move_to(self.content.len(), cx);
    }

    fn backspace(&mut self, _: &Backspace, window: &mut Window, cx: &mut Context<Self>) {
        if self.selected_range.is_empty() {
            let prev = self.previous_boundary(self.cursor_offset());
            if self.cursor_offset() == prev {
                window.play_system_bell();
                return;
            }
            self.select_to(prev, cx)
        }
        self.replace_text_in_range(None, "", window, cx)
    }

    fn delete(&mut self, _: &Delete, window: &mut Window, cx: &mut Context<Self>) {
        if self.selected_range.is_empty() {
            let next = self.next_boundary(self.cursor_offset());
            if self.cursor_offset() == next {
                window.play_system_bell();
                return;
            }
            self.select_to(next, cx)
        }
        self.replace_text_in_range(None, "", window, cx)
    }

    fn on_mouse_down(
        &mut self,
        event: &MouseDownEvent,
        _window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        self.is_selecting = true;

        if event.modifiers.shift {
            self.select_to(self.index_for_mouse_position(event.position), cx);
        } else {
            self.move_to(self.index_for_mouse_position(event.position), cx)
        }
    }

    fn on_mouse_up(&mut self, _: &MouseUpEvent, _window: &mut Window, _: &mut Context<Self>) {
        self.is_selecting = false;
    }

    fn on_mouse_move(&mut self, event: &MouseMoveEvent, _: &mut Window, cx: &mut Context<Self>) {
        if self.is_selecting {
            self.select_to(self.index_for_mouse_position(event.position), cx);
        }
    }

    fn show_character_palette(
        &mut self,
        _: &ShowCharacterPalette,
        window: &mut Window,
        _: &mut Context<Self>,
    ) {
        window.show_character_palette();
    }

    fn paste(&mut self, _: &Paste, window: &mut Window, cx: &mut Context<Self>) {
        if let Some(text) = cx.read_from_clipboard().and_then(|item| item.text()) {
            self.replace_text_in_range(None, &text, window, cx);
        }
    }

    fn copy(&mut self, _: &Copy, _: &mut Window, cx: &mut Context<Self>) {
        if !self.selected_range.is_empty() {
            cx.write_to_clipboard(ClipboardItem::new_string(
                self.content[self.selected_range.clone()].to_string(),
            ));
        }
    }
    fn cut(&mut self, _: &Cut, window: &mut Window, cx: &mut Context<Self>) {
        if !self.selected_range.is_empty() {
            cx.write_to_clipboard(ClipboardItem::new_string(
                self.content[self.selected_range.clone()].to_string(),
            ));
            self.replace_text_in_range(None, "", window, cx)
        }
    }

    fn move_to(&mut self, offset: usize, cx: &mut Context<Self>) {
        self.selected_range = offset..offset;
        cx.notify()
    }

    fn cursor_offset(&self) -> usize {
        if self.selection_reversed {
            self.selected_range.start
        } else {
            self.selected_range.end
        }
    }

    fn index_for_mouse_position(&self, position: Point<Pixels>) -> usize {
        let (Some(bounds),Some(layout))=(self.last_bounds,self.last_layout.as_ref()) else {return 0;};
        let row=((position.y-bounds.top())/layout.line_height).floor().max(0.) as usize+layout.first;
        let index=row.min(layout.lines.len()-1);
        (layout.starts[index]+layout.lines[index].closest_index_for_x(position.x-bounds.left()+layout.horizontal)).min(self.content.len())
    }

    fn compose(&mut self, range_utf16: Option<Range<usize>>, new_text: &str,
               selection_utf16: Option<Range<usize>>, cx: &mut Context<Self>) {
        let range=range_utf16.as_ref().map(|range|self.range_from_utf16(range))
            .or(self.marked_range.clone()).unwrap_or(self.selected_range.clone());
        let relative=|offset| {
            let mut units=0;
            for (byte,ch) in new_text.char_indices() {
                if units>=offset {return byte;}
                units+=ch.len_utf16();
            }
            new_text.len()
        };
        let selected=selection_utf16.map(|selected|relative(selected.start)..relative(selected.end));
        self.content=(self.content[..range.start].to_owned()+new_text+&self.content[range.end..]).into();
        self.marked_range=(!new_text.is_empty()).then_some(range.start..range.start+new_text.len());
        self.selected_range=selected.map(|selected|range.start+selected.start..range.start+selected.end)
            .unwrap_or(range.start+new_text.len()..range.start+new_text.len());
        cx.notify();
    }

    fn select_to(&mut self, offset: usize, cx: &mut Context<Self>) {
        if self.selection_reversed {
            self.selected_range.start = offset
        } else {
            self.selected_range.end = offset
        };
        if self.selected_range.end < self.selected_range.start {
            self.selection_reversed = !self.selection_reversed;
            self.selected_range = self.selected_range.end..self.selected_range.start;
        }
        cx.notify()
    }

    fn offset_from_utf16(&self, offset: usize) -> usize {
        let mut utf8_offset = 0;
        let mut utf16_count = 0;

        for ch in self.content.chars() {
            if utf16_count >= offset {
                break;
            }
            utf16_count += ch.len_utf16();
            utf8_offset += ch.len_utf8();
        }

        utf8_offset
    }

    fn offset_to_utf16(&self, offset: usize) -> usize {
        let mut utf16_offset = 0;
        let mut utf8_count = 0;

        for ch in self.content.chars() {
            if utf8_count >= offset {
                break;
            }
            utf8_count += ch.len_utf8();
            utf16_offset += ch.len_utf16();
        }

        utf16_offset
    }

    fn range_to_utf16(&self, range: &Range<usize>) -> Range<usize> {
        self.offset_to_utf16(range.start)..self.offset_to_utf16(range.end)
    }

    fn range_from_utf16(&self, range_utf16: &Range<usize>) -> Range<usize> {
        self.offset_from_utf16(range_utf16.start)..self.offset_from_utf16(range_utf16.end)
    }

    fn previous_boundary(&self, offset: usize) -> usize {
        self.content
            .grapheme_indices(true)
            .rev()
            .find_map(|(idx, _)| (idx < offset).then_some(idx))
            .unwrap_or(0)
    }

    fn next_boundary(&self, offset: usize) -> usize {
        self.content
            .grapheme_indices(true)
            .find_map(|(idx, _)| (idx > offset).then_some(idx))
            .unwrap_or(self.content.len())
    }

    fn reset(&mut self) {
        self.content = "".into();
        self.selected_range = 0..0;
        self.selection_reversed = false;
        self.marked_range = None;
        self.last_layout = None;
        self.last_bounds = None;
        self.is_selecting = false;
    }
}

impl EntityInputHandler for TextInput {
    fn text_for_range(
        &mut self,
        range_utf16: Range<usize>,
        actual_range: &mut Option<Range<usize>>,
        _window: &mut Window,
        _cx: &mut Context<Self>,
    ) -> Option<String> {
        let range = self.range_from_utf16(&range_utf16);
        actual_range.replace(self.range_to_utf16(&range));
        Some(self.content[range].to_string())
    }

    fn selected_text_range(
        &mut self,
        _ignore_disabled_input: bool,
        _window: &mut Window,
        _cx: &mut Context<Self>,
    ) -> Option<UTF16Selection> {
        Some(UTF16Selection {
            range: self.range_to_utf16(&self.selected_range),
            reversed: self.selection_reversed,
        })
    }

    fn marked_text_range(
        &self,
        _window: &mut Window,
        _cx: &mut Context<Self>,
    ) -> Option<Range<usize>> {
        self.marked_range
            .as_ref()
            .map(|range| self.range_to_utf16(range))
    }

    fn unmark_text(&mut self, _window: &mut Window, _cx: &mut Context<Self>) {
        self.marked_range = None;
    }

    fn replace_text_in_range(
        &mut self,
        range_utf16: Option<Range<usize>>,
        new_text: &str,
        _: &mut Window,
        cx: &mut Context<Self>,
    ) {
        let range = range_utf16
            .as_ref()
            .map(|range_utf16| self.range_from_utf16(range_utf16))
            .or(self.marked_range.clone())
            .unwrap_or(self.selected_range.clone());

        self.content =
            (self.content[0..range.start].to_owned() + new_text + &self.content[range.end..])
                .into();
        self.selected_range = range.start + new_text.len()..range.start + new_text.len();
        self.marked_range.take();
        cx.notify();
    }

    fn replace_and_mark_text_in_range(
        &mut self,
        range_utf16: Option<Range<usize>>,
        new_text: &str,
        new_selected_range_utf16: Option<Range<usize>>,
        _window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        self.compose(range_utf16,new_text,new_selected_range_utf16,cx);
    }

    fn bounds_for_range(
        &mut self,
        range_utf16: Range<usize>,
        bounds: Bounds<Pixels>,
        _window: &mut Window,
        _cx: &mut Context<Self>,
    ) -> Option<Bounds<Pixels>> {
        let layout=self.last_layout.as_ref()?;
        let range=self.range_from_utf16(&range_utf16);
        let start=layout.position(range.start);
        let end=layout.position(range.end);
        Some(Bounds::from_corners(bounds.origin+start, bounds.origin+point(end.x.max(start.x+px(2.)),end.y+layout.line_height)))
    }

    fn character_index_for_point(&mut self, position: Point<Pixels>, _window: &mut Window,
                                 _cx: &mut Context<Self>) -> Option<usize> {
        self.last_layout.as_ref()?;
        Some(self.offset_to_utf16(self.index_for_mouse_position(position)))
    }

}

struct TextElement {
    input: Entity<TextInput>,
}

struct InputLayout {
    lines: Vec<ShapedLine>,
    starts: Vec<usize>,
    first: usize,
    horizontal: Pixels,
    line_height: Pixels,
}
impl InputLayout {
    fn row(&self, offset: usize) -> usize {
        self.starts.iter().rposition(|start| *start <= offset).unwrap_or(0)
    }
    fn position(&self, offset: usize) -> Point<Pixels> {
        let row=self.row(offset);
        let byte=offset.saturating_sub(self.starts[row]).min(self.lines[row].text.len());
        point(self.lines[row].x_for_index(byte)-self.horizontal,
            self.line_height*(row as f32-self.first as f32))
    }
}
struct PrepaintState { layout: InputLayout, quads: Vec<PaintQuad> }
impl IntoElement for TextElement {
    type Element=Self;
    fn into_element(self)->Self::Element {self}
}
impl Element for TextElement {
    type RequestLayoutState=();
    type PrepaintState=PrepaintState;
    fn id(&self)->Option<ElementId>{None}
    fn source_location(&self)->Option<&'static core::panic::Location<'static>>{None}
    fn request_layout(&mut self,_id:Option<&GlobalElementId>,_inspector:Option<&gpui::InspectorElementId>,
                      window:&mut Window,cx:&mut App)->(LayoutId,()) {
        let mut style=Style::default();
        style.size.width=relative(1.).into();style.size.height=px(64.).into();
        (window.request_layout(style,[],cx),())
    }
    fn prepaint(&mut self,_id:Option<&GlobalElementId>,_inspector:Option<&gpui::InspectorElementId>,
                bounds:Bounds<Pixels>,_request:&mut (),window:&mut Window,cx:&mut App)->PrepaintState {
        let input=self.input.read(cx);
        let style=window.text_style();
        let display=if input.content.is_empty(){input.placeholder.clone()}else{input.content.clone()};
        let color=if input.content.is_empty(){
            rgb(if input.light{0x515b6b}else{0xa4abb8}).into()
        }else{style.color};
        let font_size=style.font_size.to_pixels(window.rem_size());
        let line_height=window.line_height();
        let mut starts=vec![];let mut lines=vec![];let mut start=0;
        for text in display.split('\n') {
            starts.push(start);
            let run=TextRun{len:text.len(),font:style.font(),color,background_color:None,underline:None,strikethrough:None};
            lines.push(window.text_system().shape_line(text.to_owned().into(),font_size,&[run],None));
            start+=text.len()+1;
        }
        let mut layout=InputLayout{lines,starts,first:0,horizontal:px(0.),line_height};
        let cursor=input.cursor_offset();
        let cursor_row=layout.row(cursor);
        layout.first=cursor_row.saturating_sub(2);
        let cursor_position=layout.position(cursor);
        layout.horizontal=(cursor_position.x-bounds.size.width+px(8.)).max(px(0.));
        let mut quads=vec![];
        if input.selected_range.is_empty() {
            if input.focus_handle.is_focused(window) {
                let position=layout.position(cursor);
                quads.push(fill(Bounds::new(bounds.origin+position,size(px(2.),line_height)),
                    rgb(if input.light{0x225a9d}else{0x83b2ff})));
            }
        } else {
            for row in layout.first..layout.lines.len().min(layout.first+3) {
                let from=input.selected_range.start.max(layout.starts[row]);
                let to=input.selected_range.end.min(layout.starts[row]+layout.lines[row].text.len());
                if from<to {
                    let from=layout.position(from);let to=layout.position(to);
                    quads.push(fill(Bounds::from_corners(bounds.origin+from,
                        bounds.origin+point(to.x,to.y+line_height)),rgba(0x83b2ff66)));
                }
            }
        }
        if let Some(marked)=&input.marked_range {
            let from=layout.position(marked.start);let to=layout.position(marked.end);
            quads.push(fill(Bounds::new(bounds.origin+point(from.x,from.y+line_height-px(2.)),
                size((to.x-from.x).max(px(2.)),px(1.))),color));
        }
        PrepaintState{layout,quads}
    }
    fn paint(&mut self,_id:Option<&GlobalElementId>,_inspector:Option<&gpui::InspectorElementId>,
             bounds:Bounds<Pixels>,_request:&mut (),prepaint:&mut PrepaintState,window:&mut Window,cx:&mut App) {
        let focus=self.input.read(cx).focus_handle.clone();
        window.handle_input(&focus,ElementInputHandler::new(bounds,self.input.clone()),cx);
        for quad in prepaint.quads.drain(..){window.paint_quad(quad);}
        let layout=&prepaint.layout;
        for row in layout.first..layout.lines.len().min(layout.first+3) {
            let origin=bounds.origin+point(-layout.horizontal,layout.line_height*(row-layout.first) as f32);
            layout.lines[row].paint(origin,layout.line_height,gpui::TextAlign::Left,None,window,cx)
                .expect("shaped line can be painted");
        }
        let layout=std::mem::replace(&mut prepaint.layout,InputLayout{lines:vec![],starts:vec![],first:0,horizontal:px(0.),line_height:px(22.)});
        self.input.update(cx,|input,_cx|{input.last_layout=Some(layout);input.last_bounds=Some(bounds);});
    }
}

impl Render for TextInput {
    fn render(&mut self, _window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        let entity=cx.entity().downgrade();
        div()
            .id("draft").role(gpui::Role::TextInput).aria_label("Message")
            .aria_value(self.content.clone()).tab_stop(true)
            .on_a11y_action(gpui::AccessibleAction::SetValue, move|data,window,cx|{
                if let Some(gpui::accesskit::ActionData::Value(value))=data {
                    let _=entity.update(cx,|input,cx|{
                        let end=input.content.encode_utf16().count();
                        input.replace_text_in_range(Some(0..end),value,window,cx);
                    });
                }
            })
            .flex()
            .key_context("TextInput")
            .track_focus(&self.focus_handle(cx))
            .cursor(CursorStyle::IBeam)
            .on_action(cx.listener(Self::backspace))
            .on_action(cx.listener(Self::delete))
            .on_action(cx.listener(Self::left))
            .on_action(cx.listener(Self::right))
            .on_action(cx.listener(Self::select_left))
            .on_action(cx.listener(Self::select_right))
            .on_action(cx.listener(Self::select_all))
            .on_action(cx.listener(Self::home))
            .on_action(cx.listener(Self::end))
            .on_action(cx.listener(Self::show_character_palette))
            .on_action(cx.listener(Self::paste))
            .on_action(cx.listener(Self::cut))
            .on_action(cx.listener(Self::copy))
            .on_mouse_down(MouseButton::Left, cx.listener(Self::on_mouse_down))
            .on_mouse_up(MouseButton::Left, cx.listener(Self::on_mouse_up))
            .on_mouse_up_out(MouseButton::Left, cx.listener(Self::on_mouse_up))
            .on_mouse_move(cx.listener(Self::on_mouse_move))
            .bg(rgb(if self.light{0xffffff}else{0x1d2027}))
            .line_height(px(22.))
            .text_size(px(13.))
            .text_color(rgb(if self.light{0x20252e}else{0xe6e8ed}))
            .child(
                div()
                    .h(px(72.))
                    .w_full()
                    .overflow_hidden()
                    .p(px(4.))
                    .bg(rgb(if self.light{0xffffff}else{0x1d2027}))
                    .child(TextElement { input: cx.entity() }),
            )
    }
}

impl Focusable for TextInput {
    fn focus_handle(&self, _: &App) -> FocusHandle {
        self.focus_handle.clone()
    }
}



#[cfg(test)]
#[path = "input.tests.rs"]
mod tests;