//! Native presentation of the same corpus and producer streams as the WebView.
mod input;
use anyhow::{Context as _, Result};
use gpui::{
    actions, div, prelude::*, px, relative, rgb, size, uniform_list, App, Bounds, Context, Entity,
    FocusHandle, Focusable, KeyBinding, Role, Window, WindowBounds, WindowOptions,
};
use input::TextInput;
use magistr_foundation_workload::{timestamp_us, Event, Fixture, StreamRun, StreamState};
use std::{
    path::PathBuf,
    time::{Duration, Instant},
};

actions!(
    foundation,
    [
        MainWorkspace,
        ReviewWorkspace,
        Changes,
        Roadmap,
        Tab,
        PreviousTab,
        Send,
        Quit,
        ClosePicker
    ]
);
#[derive(Clone, Copy)]
enum Action {
    Workspace(usize),
    Session(usize),
    Changes,
    Roadmap,
    Start,
    Stop,
    Allow,
    Deny,
    Theme,
    Motion,
    Open,
    Send,
}
#[derive(Clone, Copy)]
struct Colors {
    background: u32,
    side: u32,
    text: u32,
    muted: u32,
    line: u32,
    selected: u32,
    plus: u32,
    minus: u32,
}
impl Colors {
    fn new(light: bool) -> Self {
        if light {
            Self {
                background: 0xfaf9f6,
                side: 0xf0efeb,
                text: 0x20252e,
                muted: 0x515b6b,
                line: 0xc7ccd5,
                selected: 0xdae7f9,
                plus: 0x175d31,
                minus: 0x923737,
            }
        } else {
            Self {
                background: 0x16181d,
                side: 0x111318,
                text: 0xe6e8ed,
                muted: 0xa4abb8,
                line: 0x343944,
                selected: 0x243550,
                plus: 0x9ce0b5,
                minus: 0xf4a5a5,
            }
        }
    }
}
struct Desktop {
    fixture: Fixture,
    streams: StreamState,
    run: Option<StreamRun>,
    input: Entity<TextInput>,
    focus: FocusHandle,
    output: PathBuf,
    workspace: usize,
    session: usize,
    roadmap: bool,
    light: bool,
    reduced_motion: bool,
    waiting: bool,
    selected_item: Option<usize>,
    status: String,
    ready: bool,
    delayed: u64,
    errors: Vec<String>,
    delays: Vec<f64>,
    started: Option<Instant>,
    pending_events: Vec<Event>,
    finish_pending: bool,
    dropped: u64,
    picker: bool,
}
impl Desktop {
    fn new(cx: &mut Context<Self>, output: PathBuf) -> Self {
        let input = cx.new(TextInput::new);
        cx.observe(&input, |_, _, cx| cx.notify()).detach();
        Self {
            fixture: Fixture::new(),
            streams: StreamState::default(),
            run: None,
            input,
            focus: cx.focus_handle(),
            output,
            workspace: 0,
            session: 0,
            roadmap: false,
            light: false,
            reduced_motion: true,
            waiting: true,
            selected_item: None,
            status: "Ready to start".into(),
            ready: false,
            delayed: 0,
            errors: vec![],
            delays: vec![],
            started: None,
            pending_events: vec![],
            finish_pending: false,
            dropped: 0,
            picker: false,
        }
    }
    fn record(&self, name: &str, value: serde_json::Value) {
        if let Err(error) =
            std::fs::write(self.output.join(format!("{name}.json")), value.to_string())
        {
            // Reporting failure is evidence failure, never a manufactured measurement.
            let _ = std::fs::write(self.output.join("error.txt"), error.to_string());
        }
    }
    fn snapshot(&self, cx: &App) {
        self.record("snapshot", serde_json::json!({
            "workspace":self.workspace, "session":self.session, "draft":self.input.read(cx).value(),
            "running":self.run.is_some(), "sequences":self.streams.sequences,
            "received":self.streams.sequences.iter().sum::<u64>(), "errors":self.errors,
            "roadmap":self.roadmap,"light":self.light,"reduced_motion":self.reduced_motion,
            "waiting":self.waiting,"item":self.selected_item,"status":self.status
        }));
    }
    fn act(&mut self, action: Action, window: &mut Window, cx: &mut Context<Self>) {
        match action {
            Action::Workspace(index) => {
                self.workspace = index;
                self.picker = false;
            }
            Action::Session(index) => self.session = index,
            Action::Changes => self.roadmap = false,
            Action::Roadmap => self.roadmap = true,
            Action::Start => self.start(window, cx),
            Action::Stop => {
                self.run.take();
                self.status = "Work stopped".into();
            }
            Action::Allow | Action::Deny => {
                self.waiting = false;
                self.status = if matches!(action, Action::Allow) {
                    "Command allowed"
                } else {
                    "Command denied"
                }
                .into();
                self.record("journey",serde_json::json!({"answer":if matches!(action,Action::Allow) {"allow"} else {"deny"},"draft":self.input.read(cx).value()}));
            }
            Action::Theme => {
                self.light = !self.light;
                self.input
                    .update(cx, |input, cx| input.set_light(self.light, cx));
            }
            Action::Motion => self.reduced_motion = !self.reduced_motion,
            Action::Open => self.picker = true,
            Action::Send => {
                let text = self.input.read(cx).value().to_owned();
                if !text.trim().is_empty() {
                    self.record("journey", serde_json::json!({"sent":text}));
                    self.input.update(cx, |input, cx| input.clear(cx));
                    self.status = "Message sent".into();
                }
            }
        }
        cx.notify();
    }
    fn start(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.run.is_some() {
            return;
        }
        self.streams = StreamState::default();
        self.errors.clear();
        self.delays.clear();
        self.delayed = 0;
        self.pending_events.clear();
        self.finish_pending = false;
        self.dropped = 0;
        self.run = Some(StreamRun::start(1_250, Duration::from_millis(8)));
        self.started = self.run.as_ref().map(|run| run.started);
        self.status = "Working · 8 agents".into();
        cx.spawn_in(window, async move |this, cx| -> Result<()> {
            loop {
                cx.background_executor()
                    .timer(Duration::from_millis(8))
                    .await;
                let done = this.update_in(cx, |this, window, cx| this.pump(window, cx))?;
                if done {
                    break;
                }
            }
            Ok(())
        })
        .detach();
    }
    fn pump(&mut self, _window: &mut Window, cx: &mut Context<Self>) -> bool {
        let Some(run) = &self.run else {
            return true;
        };
        let events: Vec<_> = run.receiver.try_iter().collect();
        for event in &events {
            if let Err(error) = self.streams.apply(event) {
                self.errors.push(error);
            }
        }
        if !events.is_empty() {
            self.pending_events.extend(events);
            cx.notify();
        }
        let done = self
            .streams
            .sequences
            .iter()
            .all(|sequence| *sequence == 1_250)
            || run.dropped() > 0;
        if done {
            self.dropped = run.dropped();
            self.run.take();
            self.status = "Work complete".into();
            self.finish_pending = true;
            cx.notify();
        }
        done
    }
    fn button(
        &self,
        id: impl Into<gpui::ElementId>,
        label: &str,
        action: Action,
        cx: &Context<Self>,
    ) -> gpui::AnyElement {
        let colors = Colors::new(self.light);
        div()
            .id(id)
            .role(Role::Button)
            .aria_label(label.to_owned())
            .focusable()
            .tab_stop(true)
            .px(px(10.))
            .py(px(6.))
            .rounded(px(5.))
            .border_1()
            .border_color(rgb(colors.line))
            .bg(rgb(colors.selected))
            .cursor_pointer()
            .child(label.to_owned())
            .on_key_down(
                cx.listener(move |this, event: &gpui::KeyDownEvent, window, cx| {
                    if event.keystroke.key == "enter" || event.keystroke.key == "space" {
                        this.act(action, window, cx);
                        cx.stop_propagation();
                    }
                }),
            )
            .on_click(cx.listener(move |this, _, window, cx| this.act(action, window, cx)))
            .into_any_element()
    }
    fn sidebar(&self, cx: &Context<Self>) -> gpui::AnyElement {
        let c = Colors::new(self.light);
        div()
            .id("sidebar")
            .role(Role::Navigation)
            .aria_label("Projects and sessions")
            .w(px(224.))
            .h_full()
            .flex_none()
            .p(px(12.))
            .flex()
            .flex_col()
            .gap(px(6.))
            .bg(rgb(c.side))
            .border_r_1()
            .border_color(rgb(c.line))
            .child(
                div()
                    .h(px(42.))
                    .p(px(8.))
                    .text_size(px(18.))
                    .child("M  Magistr"),
            )
            .child(div().text_color(rgb(c.muted)).p(px(8.)).child("Workspaces"))
            .child(self.button("open", "Open workspace", Action::Open, cx))
            .child(self.button("main", "Magistr · Main branch", Action::Workspace(0), cx))
            .child(self.button(
                "review",
                "Source review · Review branch",
                Action::Workspace(1),
                cx,
            ))
            .child(
                div()
                    .text_color(rgb(c.muted))
                    .p(px(8.))
                    .child("Sessions · 8"),
            )
            .children((0..8).map(|i| {
                self.button(
                    ("session", i),
                    &format!(
                        "Agent {} · {} · {}",
                        i + 1,
                        if self.run.is_some() {
                            "Working"
                        } else if i == 2 && self.waiting {
                            "Waiting for you"
                        } else {
                            "Ready"
                        },
                        self.streams.sequences[i]
                    ),
                    Action::Session(i),
                    cx,
                )
            }))
            .child(div().flex_1())
            .child(self.button("theme", "Change theme", Action::Theme, cx))
            .child(self.button("motion", "Reduce motion", Action::Motion, cx))
            .into_any_element()
    }
    fn conversation(&self, cx: &Context<Self>) -> gpui::AnyElement {
        let c = Colors::new(self.light);
        let live = self.streams.texts[self.session]
            .lines()
            .rev()
            .take(3)
            .collect::<Vec<_>>()
            .into_iter()
            .rev()
            .collect::<Vec<_>>()
            .join("\n");
        div()
            .id("conversation-pane")
            .role(Role::Group)
            .aria_label("Conversation")
            .flex_1()
            .h_full()
            .min_w(px(250.))
            .flex()
            .flex_col()
            .child(
                div()
                    .p(px(20.))
                    .flex()
                    .flex_col()
                    .gap(px(7.))
                    .child(
                        div()
                            .text_size(px(17.))
                            .font_weight(gpui::FontWeight::SEMIBOLD)
                            .child("Keep sessions running across workspaces"),
                    )
                    .child(
                        div()
                            .id("status")
                            .role(Role::Status)
                            .aria_label(self.status.clone())
                            .text_size(px(12.))
                            .text_color(rgb(c.muted))
                            .child(self.status.clone()),
                    ),
            )
            .when(self.waiting, |view| {
                view.child(
                    div()
                        .mx(px(20.))
                        .mb(px(12.))
                        .p(px(12.))
                        .border_l_2()
                        .border_color(rgb(0xffcc80))
                        .flex()
                        .flex_col()
                        .gap(px(7.))
                        .child("Waiting for you")
                        .child("Allow the test command to run?")
                        .child(
                            div()
                                .flex()
                                .gap(px(6.))
                                .child(self.button("allow", "Allow once", Action::Allow, cx))
                                .child(self.button("deny", "Deny", Action::Deny, cx)),
                        ),
                )
            })
            .child(
                uniform_list(
                    "conversation",
                    160,
                    cx.processor(|this, range: std::ops::Range<usize>, _window, _cx| {
                        let c = Colors::new(this.light);
                        range
                            .map(|i| {
                                let lines: Vec<_> = this.fixture.messages[i].lines().collect();
                                div()
                                    .id(("message", i))
                                    .role(Role::Group)
                                    .aria_label(this.fixture.messages[i].clone())
                                    .h(px(260.))
                                    .p(px(12.))
                                    .flex()
                                    .flex_col()
                                    .gap(px(5.))
                                    .overflow_hidden()
                                    .border_b_1()
                                    .border_color(rgb(c.line))
                                    .child(
                                        div()
                                            .font_weight(gpui::FontWeight::SEMIBOLD)
                                            .child(lines[0].to_owned()),
                                    )
                                    .child(div().text_size(px(12.)).child(lines[1].to_owned()))
                                    .child(
                                        div()
                                            .font_family("Menlo")
                                            .text_size(px(11.))
                                            .text_color(rgb(if this.light {
                                                0x225a9d
                                            } else {
                                                0x83b2ff
                                            }))
                                            .child(lines[2].to_owned()),
                                    )
                                    .child(
                                        div()
                                            .text_size(px(12.))
                                            .font_weight(gpui::FontWeight::SEMIBOLD)
                                            .child(lines[3].to_owned()),
                                    )
                                    .child(
                                        div().text_size(px(12.)).child(format!("• {}", lines[4])),
                                    )
                                    .child(
                                        div().text_size(px(12.)).child(format!("• {}", lines[5])),
                                    )
                                    .child(div().text_size(px(11.)).child(lines[6].to_owned()))
                                    .child(div().text_size(px(11.)).child(lines[7].to_owned()))
                                    .child(
                                        div()
                                            .id(("evidence", i))
                                            .role(Role::Link)
                                            .aria_label("Recorded evidence")
                                            .text_size(px(11.))
                                            .text_color(rgb(if this.light {
                                                0x225a9d
                                            } else {
                                                0x83b2ff
                                            }))
                                            .child("Recorded evidence")
                                            .cursor_pointer()
                                            .on_click({
                                                let url = lines[8].to_owned();
                                                move |_, _, cx| cx.open_url(&url)
                                            }),
                                    )
                            })
                            .collect::<Vec<_>>()
                    }),
                )
                .flex_1(),
            )
            .child(
                div()
                    .id("reply")
                    .role(Role::Log)
                    .aria_label("Agent reply")
                    .aria_value(live.clone())
                    .h(px(72.))
                    .p(px(10.))
                    .overflow_hidden()
                    .font_family("Menlo")
                    .text_size(px(11.))
                    .text_color(rgb(c.plus))
                    .border_t_1()
                    .border_color(rgb(c.line))
                    .child(live),
            )
            .child(
                div()
                    .p(px(20.))
                    .flex()
                    .flex_col()
                    .gap(px(8.))
                    .border_t_1()
                    .border_color(rgb(c.line))
                    .child(
                        div()
                            .text_size(px(12.))
                            .text_color(rgb(c.muted))
                            .child("Message"),
                    )
                    .child(self.input.clone())
                    .child(
                        div()
                            .flex()
                            .justify_between()
                            .items_center()
                            .child(
                                div()
                                    .text_size(px(11.))
                                    .text_color(rgb(c.muted))
                                    .child("Shift + Return for a new line"),
                            )
                            .child(self.button("send", "Send", Action::Send, cx)),
                    ),
            )
            .into_any_element()
    }
    fn review(&self, cx: &Context<Self>) -> gpui::AnyElement {
        let c = Colors::new(self.light);
        let view = div()
            .id("review-pane")
            .role(Role::Group)
            .aria_label("Changes and evidence")
            .w(relative(0.43))
            .h_full()
            .min_w(px(260.))
            .flex()
            .flex_col()
            .border_l_1()
            .border_color(rgb(c.line))
            .child(
                div()
                    .flex()
                    .gap(px(6.))
                    .p(px(12.))
                    .border_b_1()
                    .border_color(rgb(c.line))
                    .child(self.button("changes", "Changes", Action::Changes, cx))
                    .child(self.button("roadmap", "Roadmap", Action::Roadmap, cx)),
            );
        if self.roadmap {
            view.child(div().p(px(14.)).child("Planned work · 1,000 items"))
                .child(uniform_list("items",1_000,cx.processor(|this,range: std::ops::Range<usize>,_window,cx|{
                    range.map(|i|div().id(("item",i)).role(Role::Button).aria_label(this.fixture.items[i].clone())
                        .h(px(32.)).px(px(14.)).py(px(7.)).text_size(px(11.)).overflow_hidden().cursor_pointer()
                        .child(this.fixture.items[i].clone()).on_click(cx.listener(move|this,_,_,cx|{
                            this.selected_item=Some(i);this.record("journey",serde_json::json!({"item":i,"requirements":true,"evidence":true}));cx.notify();
                        }))).collect::<Vec<_>>()
                })).flex_1())
                .child(div().p(px(14.)).flex().flex_col().gap(px(8.)).border_t_1().border_color(rgb(c.line))
                    .child("Requirements and evidence")
                    .child(self.selected_item.map(|i|self.fixture.items[i].clone()).unwrap_or_else(||"Select an item to read its requirements.".into()))
                    .child("Sessions keep running when you select another workspace.")
                    .child("Checks and source changes come from the project's owners.")
                    .child("Recorded check · Passed")).into_any_element()
        } else {
            view.child(
                div()
                    .p(px(14.))
                    .border_b_1()
                    .border_color(rgb(c.line))
                    .child("src/session.rs  +2,667 −2,667"),
            )
            .child(
                uniform_list(
                    "diff",
                    8_000,
                    cx.processor(|this, range: std::ops::Range<usize>, _, _| {
                        let c = Colors::new(this.light);
                        range
                            .map(|i| {
                                div()
                                    .h(px(24.))
                                    .px(px(14.))
                                    .py(px(4.))
                                    .font_family("Menlo")
                                    .text_size(px(11.))
                                    .overflow_hidden()
                                    .text_color(rgb(if i % 3 == 0 {
                                        c.plus
                                    } else if i % 3 == 1 {
                                        c.minus
                                    } else {
                                        c.text
                                    }))
                                    .child(this.fixture.diff[i].clone())
                            })
                            .collect::<Vec<_>>()
                    }),
                )
                .flex_1(),
            )
            .into_any_element()
        }
    }
}
impl Render for Desktop {
    fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        let c = Colors::new(self.light);
        let this = cx.entity().downgrade();
        window.on_next_frame(move|window,cx|{
            let _=this.update(cx,|this,cx|{
                if !this.ready {
                    this.ready=true;this.record("ready",serde_json::json!({"items":this.fixture.items.len(),"messages":this.fixture.messages.len(),"diff":this.fixture.diff.len()}));
                }
                let now = timestamp_us();
                for event in this.pending_events.drain(..) {
                    let delay = now.saturating_sub(event.sent_us) as f64 / 1_000.;
                    this.delays.push(delay);
                    if delay > 50. { this.delayed += 1; }
                }
                this.snapshot(cx);
                let stats=window.frame_duration_snapshot();
                if this.finish_pending {
                    this.finish_pending = false;
                    let input=window.input_latency_snapshot();
                    this.record("metrics",serde_json::json!({
                        "received":this.streams.sequences.iter().sum::<u64>(),
                        "sequences":this.streams.sequences,
                        "acknowledged_sequences":this.streams.sequences,
                        "dropped":this.dropped,"delayed":this.delayed,"delays_ms":this.delays,"errors":this.errors,
                        "draw_p95_ms":stats.draw_duration_histogram.value_at_quantile(0.95) as f64/1_000_000.,
                        "draw_samples":stats.draw_duration_histogram.len(),
                        "input_to_present_p95_ms":input.latency_histogram.value_at_quantile(0.95) as f64/1_000_000.,
                        "elapsed_ms":this.started.map(|start|start.elapsed().as_secs_f64()*1_000.),
                        "acknowledgement":"on_next_frame after GPUI drawing"
                    }));
                }
                this.record("frames",serde_json::json!({"draw_p95_ms":stats.draw_duration_histogram.value_at_quantile(0.95) as f64/1_000_000.,"draw_samples":stats.draw_duration_histogram.len()}));
            });
        });
        div()
            .id("application")
            .role(Role::Application)
            .aria_label("Magistr")
            .track_focus(&self.focus)
            .key_context("Foundation")
            .size_full()
            .flex()
            .bg(rgb(c.background))
            .text_color(rgb(c.text))
            .text_size(px(13.))
            .font_family(".AppleSystemUIFont")
            .on_action(
                cx.listener(|this, _: &MainWorkspace, w, cx| this.act(Action::Workspace(0), w, cx)),
            )
            .on_action(
                cx.listener(|this, _: &ReviewWorkspace, w, cx| {
                    this.act(Action::Workspace(1), w, cx)
                }),
            )
            .on_action(cx.listener(|this, _: &Changes, w, cx| this.act(Action::Changes, w, cx)))
            .on_action(cx.listener(|this, _: &Roadmap, w, cx| this.act(Action::Roadmap, w, cx)))
            .on_action(cx.listener(|this, _: &Send, w, cx| this.act(Action::Send, w, cx)))
            .on_action(cx.listener(|_, _: &Tab, w, cx| w.focus_next(cx)))
            .on_action(cx.listener(|_, _: &PreviousTab, w, cx| w.focus_prev(cx)))
            .on_action(cx.listener(|this, _: &ClosePicker, _, cx| {
                this.picker = false;
                cx.notify();
            }))
            .child(self.sidebar(cx))
            .child(
                div()
                    .flex_1()
                    .h_full()
                    .flex()
                    .flex_col()
                    .child(
                        div()
                            .h(px(57.))
                            .px(px(20.))
                            .flex()
                            .items_center()
                            .justify_between()
                            .border_b_1()
                            .border_color(rgb(c.line))
                            .child(div().child(if self.workspace == 0 {
                                "Magistr · main"
                            } else {
                                "Source review · review"
                            }))
                            .child(
                                div()
                                    .flex()
                                    .gap(px(12.))
                                    .items_center()
                                    .child(self.button("start", "Start work", Action::Start, cx))
                                    .child(self.button("stop", "Stop", Action::Stop, cx))
                                    .child(
                                        div()
                                            .id("marker")
                                            .role(Role::Image)
                                            .aria_label(if self.workspace == 0 {
                                                "Main branch selected"
                                            } else {
                                                "Review branch selected"
                                            })
                                            .w(px(16.))
                                            .h(px(16.))
                                            .rounded(px(3.))
                                            .bg(rgb(if self.workspace == 0 {
                                                0x83b2ff
                                            } else {
                                                0xffcc80
                                            })),
                                    ),
                            ),
                    )
                    .child(
                        div()
                            .flex_1()
                            .min_h(px(0.))
                            .flex()
                            .child(self.conversation(cx))
                            .child(self.review(cx)),
                    )
                    .child(
                        div()
                            .h(px(27.))
                            .px(px(16.))
                            .flex()
                            .items_center()
                            .justify_between()
                            .border_t_1()
                            .border_color(rgb(c.line))
                            .text_size(px(10.))
                            .text_color(rgb(c.muted))
                            .child("1,000 items · 160 messages · 8,000 diff lines")
                            .child(
                                div()
                                    .flex()
                                    .items_center()
                                    .gap(px(8.))
                                    .child(
                                        div()
                                            .id("input-marker")
                                            .role(Role::Image)
                                            .aria_label(if self.input.read(cx).value().is_empty() {
                                                "Message empty"
                                            } else {
                                                "Message entered"
                                            })
                                            .w(px(12.))
                                            .h(px(12.))
                                            .rounded(px(3.))
                                            .bg(rgb(if self.input.read(cx).value().is_empty() {
                                                0x83b2ff
                                            } else {
                                                0xffcc80
                                            })),
                                    )
                                    .child(format!(
                                        "{} characters",
                                        self.input.read(cx).value().chars().count()
                                    )),
                            ),
                    ),
            )
            .when(self.picker, |view| {
                view.child(
                    div()
                        .id("workspace-picker")
                        .role(Role::Dialog)
                        .aria_label("Open workspace")
                        .absolute()
                        .top(px(150.))
                        .left(px(320.))
                        .w(px(320.))
                        .p(px(24.))
                        .bg(rgb(c.side))
                        .border_1()
                        .border_color(rgb(c.line))
                        .rounded(px(8.))
                        .flex()
                        .flex_col()
                        .gap(px(16.))
                        .child("Open workspace")
                        .child(self.button(
                            "choose-main",
                            "Magistr · Main branch",
                            Action::Workspace(0),
                            cx,
                        ))
                        .child(self.button(
                            "choose-review",
                            "Source review · Review branch",
                            Action::Workspace(1),
                            cx,
                        )),
                )
            })
    }
}
fn main() -> Result<()> {
    let output = std::env::args()
        .nth(1)
        .map(PathBuf::from)
        .context("Pass a disposable output directory for the foundation fixture")?;
    std::fs::create_dir_all(&output)?;
    let failure = std::rc::Rc::new(std::cell::RefCell::new(None));
    let failed = std::rc::Rc::clone(&failure);
    gpui_platform::application().run(move |cx: &mut App| {
        TextInput::bind(cx);
        cx.bind_keys([
            KeyBinding::new("cmd-1", MainWorkspace, None),
            KeyBinding::new("cmd-2", ReviewWorkspace, None),
            KeyBinding::new("cmd-d", Changes, None),
            KeyBinding::new("cmd-r", Roadmap, None),
            KeyBinding::new("tab", Tab, None),
            KeyBinding::new("shift-tab", PreviousTab, None),
            KeyBinding::new("enter", Send, Some("TextInput")),
            KeyBinding::new("cmd-q", Quit, None),
            KeyBinding::new("escape", ClosePicker, None),
        ]);
        cx.on_action(|_: &Quit, cx| cx.quit());
        cx.on_window_closed(|cx, _| {
            if cx.windows().is_empty() {
                cx.quit();
            }
        })
        .detach();
        let bounds = Bounds::centered(None, size(px(1280.), px(800.)), cx);
        if let Err(error) = cx.open_window(
            WindowOptions {
                titlebar: Some(gpui::TitlebarOptions {
                    title: Some("Magistr".into()),
                    ..Default::default()
                }),
                window_bounds: Some(WindowBounds::Windowed(bounds)),
                ..Default::default()
            },
            |window, cx| {
                let view = cx.new(|cx| Desktop::new(cx, output));
                let focus = view.read(cx).input.read(cx).focus_handle(cx);
                window.focus(&focus, cx);
                view
            },
        ) {
            *failed.borrow_mut() = Some(error);
            cx.quit();
        }
        cx.activate(true);
    });
    failure.borrow_mut().take().map_or(Ok(()), Err)
}
