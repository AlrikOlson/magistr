//! Deterministic, presentation-only data for comparing desktop foundations.
mod workload;
pub use workload::{timestamp_us, Event, Fixture, StreamCancellation, StreamRun, StreamState};
