#!/usr/bin/env python3
"""Import measured artifacts and freeze the compared sources before pruning."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import plistlib
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent.parent
EVIDENCE = PROJECT / "docs/evidence/desktop-foundation"
ASSETS = PROJECT / "docs/assets/desktop-foundation"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def freeze():
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    inputs = sorted(path for path in ROOT.rglob("*") if path.is_file()
                    and not any(part in ("target", "results", "__pycache__") for part in path.relative_to(ROOT).parts))
    sources = {str(path.relative_to(ROOT)): digest(path) for path in inputs}
    with tarfile.open(EVIDENCE / "comparison-source.tar.gz", "w:gz") as archive:
        for path in inputs:
            archive.add(path, arcname=str(Path("desktop-foundation") / path.relative_to(ROOT)))
    binary_hashes = {}
    for name in ("tauri", "gpui"):
        path = ROOT / "target/release" / ("magistr-foundation-" + name)
        binary_hashes[name] = digest(path)
    webkit = plistlib.loads(Path("/System/Library/Frameworks/WebKit.framework/Resources/Info.plist").read_bytes())
    def command(*args):
        return subprocess.check_output(args, text=True).strip()
    metadata = {
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "git_base": command("git", "rev-parse", "HEAD"),
        "rustc": command("rustc", "+1.99.0", "--version", "--verbose"),
        "toolchains": command("rustup", "toolchain", "list").splitlines(),
        "hardware": {
            "cpu": command("sysctl", "-n", "machdep.cpu.brand_string"),
            "cores": int(command("sysctl", "-n", "hw.ncpu")),
            "memory_bytes": int(command("sysctl", "-n", "hw.memsize")),
            "model": command("sysctl", "-n", "hw.model"),
        },
        "macos": command("sw_vers", "-productVersion"),
        "os_build": command("sw_vers", "-buildVersion"),
        "webkit": {key: webkit.get(key) for key in ("CFBundleShortVersionString", "CFBundleVersion")},
        "gpui_commit": command("git", "-C", "/private/tmp/magistr-gpui-foundation-c66312b", "rev-parse", "HEAD"),
        "sources_sha256": sources,
        "release_binaries_sha256": binary_hashes,
        "archive_sha256": digest(EVIDENCE / "comparison-source.tar.gz"),
    }
    write(EVIDENCE / "build.json", metadata)
    print(json.dumps({"sources": len(inputs), "archive_sha256": metadata["archive_sha256"], "hardware": metadata["hardware"]}))


def imports(performance, journeys):
    performance = Path(performance)
    destination = EVIDENCE / "performance"
    for name in ("environment.json", "cold-launches.json", "comparison.json"):
        destination.mkdir(parents=True, exist_ok=True)
        shutil.copy2(performance / name, destination / name)
    for backend in ("tauri", "gpui"):
        for number in range(3):
            source = performance / backend / ("run-" + str(number))
            target = destination / backend / ("run-" + str(number))
            target.mkdir(parents=True, exist_ok=True)
            for name in ("results.json", "typing.json", "latency.json", "motion.json", "accessibility.json"):
                shutil.copy2(source / name, target / name)
            shutil.copy2(source / "active/metrics.json", target / "metrics.json")
        source = Path(journeys) / backend
        target = EVIDENCE / "journeys" / backend
        target.mkdir(parents=True, exist_ok=True)
        for name in ("journeys.json", "ime.json", "changes.json", "multilingual.json", "workspace-picker.json", "roadmap.json"):
            shutil.copy2(source / name, target / name)
        assets = ASSETS / backend
        assets.mkdir(parents=True, exist_ok=True)
        for name in ("dark", "light", "narrow", "multilingual", "workspace-picker", "changes", "roadmap", "ime"):
            shutil.copy2(source / (name + ".png"), assets / (name + ".png"))
        # Real reader captures come from the earlier ordinary-keyboard exercise.
        voiceover = Path("/private/tmp/magistr-foundation-voiceover-" + backend)
        target = EVIDENCE / "voiceover" / backend
        target.mkdir(parents=True, exist_ok=True)
        for source in voiceover.glob("*.json"):
            if source.name in ("ready.json", "metrics.json", "snapshot.json", "tree.json", "multilingual.json", "ime.json"):
                continue
            shutil.copy2(source, target / source.name)
        indices = ("walk-0", "walk-18") if backend == "tauri" else ("interact", "navigation-0", "navigation-3")
        for name in indices:
            shutil.copy2(voiceover / (name + ".png"), assets / ("voiceover-" + name + ".png"))
    manifest = {}
    for root in (EVIDENCE, ASSETS):
        for path in root.rglob("*"):
            if path.is_file() and path.name != "manifest.json":
                manifest[str(path.relative_to(PROJECT))] = digest(path)
    write(EVIDENCE / "manifest.json", manifest)
    print(json.dumps({"imported_artifacts": len(manifest)}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("freeze", "import"))
    parser.add_argument("--performance", type=Path)
    parser.add_argument("--journeys", type=Path)
    args = parser.parse_args()
    if args.mode == "freeze":
        freeze()
    else:
        imports(args.performance, args.journeys)


if __name__ == "__main__":
    main()
